var sql = require('mssql');

//configuraçoes do banco
const config = {
   user: 'infoco',
   password: '1nf0c0.',
   server: '10.22.75.120',
   database: '',
   pool: {
       max: 10,
       min: 0,
       idleTimeoutMillis: 30000
   }
}

//fazendo a conexão global
exports.connect = sql.connect(config)
   .then(conn => global.conn = conn)
   .catch(err => console.log(err));



//funcao para executar select
exports.select = function select(sqlQry, res){
    global.conn.request()
               .query(sqlQry)
               .then(result => res.json(result.recordset))
               .catch(err => res.json(err));
}


//funcao para executar insert
exports.insert = function insert(sqlQry, res){
   global.conn.request()
              .query(sqlQry)
              .then(result => res.json(result.rowsAffected))
              .catch(err => res.json(err));
}

