CREATE TABLE [dbo].[gestech_log](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[nu_ba] [varchar](50) NULL,
	[fl_enviado] [bit] NULL
) ON [PRIMARY]