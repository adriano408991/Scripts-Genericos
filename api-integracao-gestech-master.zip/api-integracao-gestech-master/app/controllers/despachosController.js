var cryptoHelper = require('../Helpers/crypto');
var request = require('request-promise');
var database = require('../database/config');

//cadastro
exports.post = (req, res, next) => {    
    //monta xml
    let xml = '<BASDADOS><BA ' + 
    'chavevalidacao="' + cryptoHelper.getSHA1(req.body.nrba) +'"' +
    ' observacoes="' + req.body.observacoes +'"' +
    ' area="' + req.body.area +'"' +
    ' gra="' + req.body.gra +'"' +
    ' tecnologia_tipo="' + req.body.tecnologia_tipo +'"' +
    ' tecnologia="' + req.body.tecnologia +'"' +
    ' veloc_tipo="' + req.body.veloc_tipo +'"' +
    ' velocidade="' + req.body.velocidade +'"' +
    ' produto="' + req.body.produto +'"' +
    ' estacao_b="' + req.body.estacao_b +'"' +
    ' endereco_ptb="' + req.body.endereco_ptb +'"' +
    ' estacao_a="' + req.body.estacao_a +'"' +
    ' endereco_pta="' + req.body.endereco_pta +'"' +
    ' cliente="' + req.body.cliente +'"' +
    ' cpf="' + req.body.cpf +'"' +
    ' data_agendamento="' + req.body.data_agendamento +'"' +
    ' dhr_despacho="' + req.body.dhr_despacho +'"' +
    ' nome_tecnico="' + req.body.nome_tecnico +'"' +
    ' atividade="' + req.body.atividade +'"' +
    ' matricula_tr="' + req.body.matricula_tr +'"' +
    ' macroatividade="' + req.body.macroatividade +'"' +
    ' servico="' + req.body.servico +'"' +
    ' circuito="' + req.body.circuito +'"' +
    ' protocolo="' + req.body.protocolo +'"' +
    ' nrba="' + req.body.nrba +'"' +
    ' empresa="' + req.body.empresa +'"'
    + ' /></BASDADOS>';
    res.set('Content-Type', 'text/xml');

    // options url 
    var options = {
        method: 'POST',
        uri: 'https://oigestech-quality.myteam.com.br/engineGestechQuality/Utilitarios/XmlReceiver_BAsDados.aspx',
        form: {
            XML_IN: xml
        },
        json: true
    };
    //request http
    request(options)
        .then(function (parsedBody) {
            database.insert("insert into [SEREDE].[dbo].[gestech_log] values ('"+req.body.nrba+"',1)",res);
        })
        .catch(function (err) {
            res.json({message:"erro"});
        });    
};

