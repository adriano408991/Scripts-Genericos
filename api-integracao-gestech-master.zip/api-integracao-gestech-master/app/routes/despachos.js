var express = require('express');
var router = express.Router();
//importa despachosController para a rota despachos
const controller = require('../controllers/despachosController')

//rota criar despachos
router.post('/', controller.post);

module.exports = router;
