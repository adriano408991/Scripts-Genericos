sha1 = require('js-sha1');

// funcao para gerar sha1
exports.getSHA1 = getSHA1 = function(input){
    return sha1(input)
}